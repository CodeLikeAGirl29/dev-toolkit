export const uuId = 'ae71ae62-289b-4e6c-9b6c-c55a10cb641b';
export const apiToken = '48e78186-1a03-431c-856e-d2c58f38e012';
